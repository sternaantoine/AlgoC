

#include "repertoire.h"



int main(){

    lire_dossier_recursif("..");
    lire_dossier_iteratif("..");

    return 0;
}