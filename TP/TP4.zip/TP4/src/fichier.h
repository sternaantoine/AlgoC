/*
# Antoine STERNA - 2020
# <antoine.sterna@cpe.fr>
# fichier.h
*/
#include <stdio.h>
#include <stdlib.h>

void ecrire_dans_fichier(char *nom_de_fichier, char *message);
void lire_fichier(char *nom_de_fichier);
