/*
# Antoine STERNA - 2020
# <antoine.sterna@cpe.fr>
# opérator.h
*/
#include <stdio.h>
#include <stdbool.h>

int somme(int num1, int num2);
int difference(int num1, int num2);
int modulo(int num1, int num2);
int et(int num1, int num2);
int ou(int num1, int num2);
int negation(int num1);
float produit(int num1, int num2);
float quotient(int num1, int num2);