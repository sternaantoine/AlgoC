/*
# Antoine STERNA - 2020
# <antoine.sterna@cpe.fr>
# bonjour.c
*/
#include <stdio.h>

int main()
{

    printf("Bonjour le monde !\n");
    return 0;
}